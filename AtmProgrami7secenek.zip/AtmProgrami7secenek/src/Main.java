import java.util.Scanner;
public class Main {
    public static void main(String[] args) {


        Scanner sc = new Scanner(System.in);
        String username, password;
        int rigt = 3;
        int select;
        int balance = 1500;
        int krediNotu = 100;
        int myKrNot=0;

        while (rigt > 0) {
            System.out.print("Kullanıcı adını giriniz: ");
            username = sc.nextLine();
            System.out.print("Parolanız: ");
            password = sc.nextLine();

            if (username.equals("patika") && password.equals("dev123")) {
                System.out.println("Girilen bilgiler doğru");
                do {
                    System.out.println("""
                            """ +
                            "1 - Para Yatırma \n" +
                            "2 - Para Çekme \n" +
                            "3 - Bakiye Sorgulama \n" +
                            "4 - IBAN'a Para Gönderme \n" +
                            "5 - Kredi Çekme \n" +
                            "6 - Fatura Ödeme \n" +
                            "7 - kurum ödemeleri \n" +
                            "8 - kredi notu hesaplama \n" +
                            "9 çıkış"
                    );
                    System.out.print("Yapmak istediğiniz işlemi giriniz: ");
                    select = sc.nextInt();

                    if (select == 1) {
                        System.out.print("Para miktarı: ");
                        int price = sc.nextInt();
                        balance += price;

                    } else if (select == 2) {
                        System.out.print("Para miktarı: ");
                        int price = sc.nextInt();
                        if (price > balance) {
                            System.out.println("Bakiye yetersiz");
                        } else {
                            balance -= price;
                        }

                    } else if (select == 3) {
                        System.out.println("Bakiyeniz: " + balance);

                    } else if (select == 4) {
                        System.out.print("Göndermek istediğiniz IBAN'ı giriniz: ");
                        String iban = sc.next(); // IBAN'ı al
                        System.out.print("Göndermek istediğiniz miktarı giriniz: ");
                        int amount = sc.nextInt();
                        if (amount > balance) {
                            System.out.println("Bakiye yetersiz");
                        } else {
                            balance -= amount;
                            System.out.println("Başarıyla " + iban + " IBAN'ına " + amount + " TL gönderildi.");
                        }

                    } else if (select == 5) {
                        System.out.print("Çekmek istediğiniz kredi miktarını giriniz: ");
                        int loanAmount = sc.nextInt();
                        // Basit bir kredi verme mekanizması
                        if (loanAmount <= 0) {
                            System.out.println("Geçersiz kredi miktarı.");
                        } else {
                            // Kredi miktarını bakiyeye ekleme
                            balance += loanAmount;
                            System.out.println("Başarıyla " + loanAmount + " TL kredi çekildi.");
                        }

                    } else if (select == 6) {
                        System.out.print("Ödemek istediğiniz fatura miktarını giriniz: ");
                        int billAmount = sc.nextInt();
                        if (billAmount > balance) {
                            System.out.println("Bakiye yetersiz, fatura ödemesi yapılamadı.");
                        } else {
                            balance -= billAmount;
                            System.out.println("Başarıyla " + billAmount + " TL fatura ödendi.");
                        }
                    } else if (select == 7) {
                        int kurumödmlriSelect = 0;
                        do {
                            System.out.println("""
                                    """ +
                                    "1 - elektirik faturası ödemesi \n" +
                                    "2 - su faturası ödemesi \n" +
                                    "3 - telefon faturası ödemesi \n" +
                                    "4 - geri dön ");
                            kurumödmlriSelect = sc.nextInt();
                            if (kurumödmlriSelect == 1) {
                                System.out.println("elektirik faturası tutarını giriniz");
                                int elektirik = sc.nextInt();
                                if (elektirik > balance) {
                                    System.out.println("bakiye yetersiz");
                                } else {
                                    balance -= elektirik;
                                    System.out.println("işlem başarıyla gerçekleştirildi");
                                }
                            } else if (kurumödmlriSelect == 2) {
                                System.out.println("su faturası tutarını giriniz");
                                int su = sc.nextInt();
                                if (su > balance) {
                                    System.out.println("bakiye yetersiz");

                                } else {
                                    balance -= su;
                                    System.out.println("işlem başarılı");
                                }
                            } else if (kurumödmlriSelect == 3) {
                                System.out.println("telefon faturası tutarını giriniz");
                                int telefon = sc.nextInt();

                                if (telefon > balance) {
                                    System.out.println("bakiyeniz yetersiz");
                                } else {
                                    balance -= telefon;
                                    System.out.println("işlem başarılı");

                                }
                            } else if (kurumödmlriSelect == 4) {
                                System.out.println("geri dönülüyor . . .");
                            } else {
                                System.out.println("geçersiz işlem yaptınız.");
                            }

                        } while (kurumödmlriSelect != 4);
                    } else if (select == 8) {
                        CreditScore creditScore = new CreditScore(krediNotu);
                        System.out.println("mevcut kredi notunuz : " + creditScore.getCreditScore());
                        krediNotu = creditScore.calculateNewCreditScore(balance);





                } else if (select == 9) {
                        System.out.println("çıkış yapılıyor . . .");

                    }else{
                        System.out.println("geçersiz işlem");
                    }
                }while (select !=9);
            }else{
                rigt--;
                System.out.println("bilgiler yanlış");
                if (rigt ==0){
                    System.out.println("hesabınız bloke olmuştur");
                }else {
                    System.out.println("kalan hakkınız " + rigt);
                }
            }
        }
    }

}



