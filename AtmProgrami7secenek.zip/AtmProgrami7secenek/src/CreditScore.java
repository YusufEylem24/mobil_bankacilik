public class CreditScore {

    private int creditScore;
    public CreditScore ( int score){
        this.creditScore = score;
    }

    public  int calculateNewCreditScore(int balance){
        if (balance >1000){
            creditScore += 10;
            if (balance >2000){
                creditScore += 50;

            }
        }else{
            creditScore-= 5;
        }
        if(balance>200){
            creditScore -= 60;
            if(creditScore <50){
                System.out.println("kredi notunuz 50'den az olduğu için herhangi bir kredi çekme işlemi yapamazsınız  ");
                System.out.println("ödemelerinizi düzenli ödemeniz halinde kredi notunuz yükselecektir. ");
            }

        }
        System.out.println("yeni kredi notunuz : " + creditScore);
        return creditScore;

    }
    public  int getCreditScore(){
        return  creditScore;
    }


}